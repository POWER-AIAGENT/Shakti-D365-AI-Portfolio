# Shakti Ranjan Mohanty — D365 SCM Portfolio

Modern Microsoft Dynamics 365–style, responsive single-page portfolio with CSS/JavaScript AI animation. No build tools or external dependencies are required.

## GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html` and this `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select the `main` branch and `/ (root)` folder, then Save.
6. GitHub will publish the site at your Pages URL.

## Notes
- The site is intentionally dependency-free for simple GitHub Pages hosting.
- Replace or add a CV PDF link if you want a downloadable CV button.
- The AI section describes the user's research direction and target positioning; it does not claim current AI certification.
- `*` ERP/product consulting duration is rounded from the CV timeline.
